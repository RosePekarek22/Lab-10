function setup() {
   createCanvas(600, 600);
 
}
function draw() {
 background(10);

setCenter(width/2, height/2);

polarEllipses(15, 20, 20, 200, function(...args) {
noStroke();
fill(args[0]*2, args[0]*3, args[0]*4, 200);
	args[2] = args[0]*5
	args[3] = args[0]*5
	args[4] = args[0]*25
	return args;
});
rotate(9.5)
polarEllipses(15, 20, 20, 200, function(...args) {
noStroke();
fill(args[0]*2, args[0]*3, args[0]*4, 200);
	args[2] = args[0]*5
	args[3] = args[0]*5
	args[4] = args[0]*25
	return args;
});

rotate(-9.5)
stroke(255,255,255,50);
polarLines(20, 50, 350);

noStroke();
fill(150,100,200,50);
polarEllipses(10,100,100,210);


fill(200,50,100,50);
polarHexagons(6,100,200);
stroke(200,220,20,50);
strokeWeight(2);
polarLines(4,50,200);

polarEllipses(10, 0, 0, 200, function(...args) {
noStroke();
fill(args[0]*3, args[0]*4, args[0]*5, 200);
	args[2] = args[0]*3
	args[3] = args[0]*3
	args[4] = args[0]*10
	return args;
});
rotate(9.5);
polarEllipses(10, 0, 0, 200, function(...args) {
noStroke();
fill(args[0]*3, args[0]*4, args[0]*5, 200);
	args[2] = args[0]*3
	args[3] = args[0]*3
	args[4] = args[0]*10
	return args;
});

}

